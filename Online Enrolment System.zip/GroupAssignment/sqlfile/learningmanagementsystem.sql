-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2021 at 09:24 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `learningmanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `courseCode` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `courseName` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `coursePrice` int(20) DEFAULT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `courseCode`, `courseName`, `coursePrice`, `status`, `creationDate`, `updationDate`) VALUES
(41, 'ICT2113', 'Objected Oriented Programming', 1000, 'Active', '2021-11-14 00:12:06', '14-11-2021 12:19:22 '),
(42, 'IBM2105', 'Introduction to Mobile Apps Development', 1000, 'Active', '2021-11-14 00:12:16', NULL),
(43, 'ICT1105', 'Introduction to Database', 1000, 'Active', '2021-11-14 00:12:23', NULL),
(44, 'ICT1103', 'Introduction to Internet Techhnology', 1000, 'Active', '2021-11-14 00:12:52', NULL),
(45, 'MGT1103', 'Fundamental of Management', 1000, 'Active', '2021-11-14 00:13:42', NULL),
(46, 'ICT2108', 'Introduction to Digital Image Editing', 1000, 'Active', '2021-11-14 00:14:02', NULL),
(47, 'ICT1107', 'Introduction to Cloud Computing', 1000, 'Active', '2021-11-14 00:14:48', NULL),
(48, 'IBM2104', 'Introduction to Web Programming with PHP', 1000, 'Active', '2021-11-14 01:29:31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `courseenrolls`
--

CREATE TABLE `courseenrolls` (
  `id` int(11) NOT NULL,
  `studentRegno` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `studentName` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pincode` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `semester` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `price` int(255) NOT NULL,
  `course` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `enrollDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courseenrolls`
--

INSERT INTO `courseenrolls` (`id`, `studentRegno`, `studentName`, `pincode`, `semester`, `price`, `course`, `enrollDate`) VALUES
(49, 'J20033078', 'Chang Yu Qian', '376723', '', 1, '43', '2021-11-14 00:31:18'),
(50, 'J20033078', 'Chang Yu Qian', '376723', '1', 1, '41', '2021-11-14 00:34:00'),
(51, 'J20033078', 'Chang Yu Qian', '376723', '1', 1, '43', '2021-11-14 01:03:48'),
(52, 'J20033077', 'Tan Yu Jie', '672300', '1', 1, '43', '2021-11-14 01:39:41'),
(53, 'J20033077', 'Tan Yu Jie', '672300', '1', 1, '41', '2021-11-14 01:39:47'),
(54, 'J20033078', 'Chang Yu Qian', '376723', '1', 1, '46', '2021-11-14 03:29:59'),
(55, 'J20033078', 'Chang Yu Qian', '376723', '1', 1, '44', '2021-11-14 03:41:45');

-- --------------------------------------------------------

--
-- Table structure for table `coursemodule`
--

CREATE TABLE `coursemodule` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `courseName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `headofprogram`
--

CREATE TABLE `headofprogram` (
  `id` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `headofprogram`
--

INSERT INTO `headofprogram` (`id`, `username`, `password`, `creationDate`, `updationDate`) VALUES
(1, 'instructor', 'f925916e2754e5e03f75dd58a5733251', '2021-10-31 16:21:18', '11-11-2021 02:07:06 PM'),
(2, 'instrcutor2', 'f925916e2754e5e03f75dd58a5733251', '2021-11-14 08:17:03', ''),
(3, 'instrcutor3', 'f925916e2754e5e03f75dd58a5733251', '2021-11-14 08:17:03', ''),
(4, 'instructor4', 'f925916e2754e5e03f75dd58a5733251', '2021-11-14 08:18:00', ''),
(5, 'instructor5', 'f925916e2754e5e03f75dd58a5733251', '2021-11-14 08:18:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `id` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`id`, `username`, `password`, `creationDate`, `updationDate`) VALUES
(1, 'lecturer', 'f925916e2754e5e03f75dd58a5733251', '2021-10-31 16:21:18', '2021-11-14 11:46:17'),
(2, 'lecturer2', 'f925916e2754e5e03f75dd58a5733251', '2021-11-12 08:03:24', ''),
(3, 'lecturer3', 'f925916e2754e5e03f75dd58a5733251', '2021-11-12 08:03:24', ''),
(4, 'lecturer4', 'f925916e2754e5e03f75dd58a5733251', '2021-11-14 08:17:38', ''),
(5, 'lecturer5', 'f925916e2754e5e03f75dd58a5733251', '2021-11-14 08:17:38', '');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `studentRegno` varchar(255) NOT NULL,
  `studentName` varchar(255) NOT NULL,
  `price` int(255) DEFAULT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `month` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `studentRegno`, `studentName`, `price`, `date`, `month`) VALUES
(22, 'J20033078', 'Chang Yu Qian', 1000, '2021-11-12', 'November'),
(24, 'J20033078', 'Chang Yu Qian', 1000, '2021-11-12', 'November'),
(25, 'J20033078', 'Chang Yu Qian', 1000, '2021-11-12', 'November'),
(26, 'J20033077', 'Tan Yu Jie', 1000, '2021-11-14', 'November'),
(28, 'J20033077', 'Tan Yu Jie', 1000, '2021-11-14', 'November'),
(29, 'J20033077', 'Tan Yu Jie', 1000, '2021-11-14', 'November'),
(34, 'J20033078', 'Chang Yu Qian', 1000, '2021-11-14', 'November'),
(35, 'J20033078', 'Chang Yu Qian', 1000, '2021-11-14', 'November');

-- --------------------------------------------------------

--
-- Table structure for table `price`
--

CREATE TABLE `price` (
  `id` int(11) NOT NULL,
  `price` int(100) NOT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `price`
--

INSERT INTO `price` (`id`, `price`, `date`) VALUES
(1, 1000, '2021-11-12 10:19:38');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id` int(11) NOT NULL,
  `semester` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id`, `semester`, `creationDate`) VALUES
(1, 'sem 1', '2021-11-14 00:29:40'),
(2, 'sem 2', '2021-11-14 00:29:45'),
(3, 'sem 3', '2021-11-14 04:14:12');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `StudentRegno` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `studentName` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pincode` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `creationdate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`StudentRegno`, `password`, `studentName`, `pincode`, `email`, `creationdate`, `updationDate`) VALUES
('J20033070', '81dc9bdb52d04dc20036dbd8313ed055', 'Bernie See', '254642', 'j20033070@student.newinti.edu.my', '2021-11-14 08:13:17', NULL),
('J20033071', '81dc9bdb52d04dc20036dbd8313ed055', 'Franwee Chuw', '518378', 'j20033071@student.newinti.edu.my', '2021-11-14 08:18:49', NULL),
('J20033072', '202cb962ac59075b964b07152d234b70', 'Lee Mei Mei', '201783', 'j20033072@student.newinti.edu.my', '2021-11-14 08:19:12', NULL),
('J20033073', '202cb962ac59075b964b07152d234b70', 'Chan Yuan Zheng', '324978', 'j20033073@student.newinti.edu.my', '2021-11-14 08:20:36', NULL),
('J20033075', '81dc9bdb52d04dc20036dbd8313ed055', 'Lee Young Juin', '195117', 'j20033075@student.newinti.edu.my', '2021-11-09 09:57:20', NULL),
('J20033077', '81dc9bdb52d04dc20036dbd8313ed055', 'Tan Yu Jie', '672300', 'j20033077@student.newinti.edu.my', '2021-11-09 09:56:47', NULL),
('J20033078', '81dc9bdb52d04dc20036dbd8313ed055', 'Chang Yu Qian', '376723', 'j20033078@student.newinti.edu.my', '2021-11-09 09:19:40', '2021-11-14 11:30:47 ');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `studentRegno` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `studentRegno`, `loginTime`, `logout`) VALUES
(7, 'J20033078', '2021-11-12 06:48:17', '12-11-2021 02:48:20 PM'),
(8, 'J20033078', '2021-11-12 06:54:16', '2021-11-12 14:54:17 PM'),
(9, 'J20033078', '2021-11-12 08:38:59', NULL),
(10, 'J20033078', '2021-11-12 08:45:24', NULL),
(11, 'J20033078', '2021-11-12 08:53:53', '12-11-2021 02:29:46 PM'),
(12, 'J20033078', '2021-11-12 09:12:23', NULL),
(13, 'J20033078', '2021-11-12 12:43:09', NULL),
(14, 'J20033078', '2021-11-12 13:08:22', '2021-11-12 21:10:32 '),
(15, 'J20033078', '2021-11-12 13:11:39', '2021-11-12 21:12:57 '),
(16, 'J20033078', '2021-11-12 13:13:02', '2021-11-12 21:14:32 '),
(17, 'J20033078', '2021-11-12 13:19:00', NULL),
(18, 'J20033078', '2021-11-12 14:33:57', NULL),
(19, 'J20033078', '2021-11-12 14:37:42', NULL),
(20, 'J20033078', '2021-11-13 13:51:23', NULL),
(21, 'J20033077', '2021-11-13 14:12:56', '2021-11-13 22:15:31 '),
(22, 'J20033078', '2021-11-13 14:15:34', '2021-11-13 22:21:16 '),
(23, 'J20033077', '2021-11-13 14:21:21', '2021-11-13 22:28:22 '),
(24, 'J20033078', '2021-11-13 14:47:12', NULL),
(25, 'J20033078', '2021-11-14 00:10:51', '2021-11-14 09:39:23 '),
(26, 'J20033077', '2021-11-14 01:39:28', '2021-11-14 09:41:35 '),
(27, 'J20033078', '2021-11-14 01:41:37', NULL),
(28, 'J20033078', '2021-11-14 03:29:41', '2021-11-14 11:30:53 '),
(29, 'J20033078', '2021-11-14 03:30:56', '2021-11-14 11:30:58 '),
(30, '', '2021-11-14 03:36:20', NULL),
(31, 'J20033078', '2021-11-14 03:36:25', '2021-11-14 11:44:12 '),
(32, 'J20033078', '2021-11-14 04:21:59', '2021-11-14 12:22:00 '),
(33, 'J20033078', '2021-11-14 04:29:17', '2021-11-14 12:33:29 '),
(34, 'J20033078', '2021-11-14 06:46:56', '2021-11-14 15:50:18 ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courseenrolls`
--
ALTER TABLE `courseenrolls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coursemodule`
--
ALTER TABLE `coursemodule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `headofprogram`
--
ALTER TABLE `headofprogram`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `price`
--
ALTER TABLE `price`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`StudentRegno`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `courseenrolls`
--
ALTER TABLE `courseenrolls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `headofprogram`
--
ALTER TABLE `headofprogram`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lecturer`
--
ALTER TABLE `lecturer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `price`
--
ALTER TABLE `price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
