<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kuala_Lumpur');//Kuala Lumpur Timezone
$currentTime = date( 'Y-m-d H:i:s ', time ()  );//exp output: 2021-8-31- 18:33


if(isset($_POST['submit']))//when user press the submit button system will run these codes
{
$sql=mysqli_query($con,"SELECT password FROM  headofprogram where password='".md5($_POST['cpass'])."' && username='".$_SESSION['alogin']."'");//find current password
$num=mysqli_fetch_array($sql);
if($num>0)
{
 $con=mysqli_query($con,"update headofprogram set password='".md5($_POST['newpass'])."', updationDate='$currentTime' where username='".$_SESSION['alogin']."'");//update new password
$_SESSION['msg']="Password Changed Successfully !!";//inform users when password changed successfully
}
else
{
$_SESSION['msg']="Old Password not match !!";//inform users when current password is wrong
}
}
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>HOP | Change Password</title><!--Title of the page-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>
<script type="text/javascript">//using javascript language to check whether the password field is empty or user already input data
function valid()
{
if(document.chngpwd.cpass.value=="")//check current password field
{
alert("Current Password Field is Empty !!");//system will display this message if current password field is empty
document.chngpwd.cpass.focus();
return false;
}
else if(document.chngpwd.newpass.value=="")//check new password field
{
alert("New Password Field is Empty !!");//system will display this message if new password field is empty
document.chngpwd.newpass.focus();
return false;
}
else if(document.chngpwd.cnfpass.value=="")//check confirm password field
{
alert("Confirm Password Field is Empty !!");//system will display this message if confirm password field is empty
document.chngpwd.cnfpass.focus();
return false;
}
else if(document.chngpwd.newpass.value!= document.chngpwd.cnfpass.value)//check new password and confirm password field
{
alert("Password and Confirm Password Field do not match  !!");//system will display this message when the data in new password and confirm password field not match
document.chngpwd.cnfpass.focus();
return false;
}
return true;
}
</script>
<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include header.php file to display menubar
}
 ?>
    <div class="content-wrapper"><!--content-wrapper-->
        <div class="container"><!--container-->
              <div class="row"><!--row-->
                    <div class="col-md-3"><!--col-md-3 -->
                        <h1 class="page-head-line"> Change Password </h1>
                    </div><!--row section end-->
                </div><!--col-md-3 section end-->
                <div class="row" ><!--row-->
                  <div class="col-md-1"></div><!-- to display the table in center -->
                    <div class="col-md-2"><!--col-md-2 -->
                        <div class="panel panel-default"><!--panel default -->
                        <div class="panel-heading"><!--panel heading -->
                           Change Password
                        </div><!--panel heading section end-->
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>


   <div class="panel-body"><!--panel body -->
   <form name="chngpwd" method="post" onSubmit="return valid();"><!--Change Password form-->
   <div class="form-group"><!--form group-->
    <label for="exampleInputPassword1">Current Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" name="cpass" placeholder="Password" /><!--User enter current password field-->
  </div><!--form group section end -->
  
   <div class="form-group"><!--form group-->
    <label for="exampleInputPassword1">New Password</label>
    <input type="password" class="form-control" id="exampleInputPassword2" name="newpass" placeholder="Password" /><!--User enter new password field-->
  </div><!--form group section end -->
  
  <div class="form-group"><!--form group-->
    <label for="exampleInputPassword1">Confirm Password</label>
    <input type="password" class="form-control" id="exampleInputPassword3" name="cnfpass" placeholder="Password" /><!--User enter confirm password field-->
  </div><!--form group section end -->
 
  <button type="submit" name="submit" class="btn btn-1">Submit</button><!--submit button-->
                           <hr />
</form><!--Change Password form end-->
 </div><!--panel body section end-->
</div><!--panel default section end-->
</div><!--col-md-2 section end-->
</div><!--row section end-->
</div><!--container section end-->
</div><!--content-wrapper end-->
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<?php } ?>
<!--End of the Code-->