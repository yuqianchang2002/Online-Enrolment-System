<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{



?>

<html>
<head>
    <meta charset="utf-8" />
    <title>HOP | Payment History</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Payment History  </h1>
                    </div>
                </div>
                <div class="row" >
            
                <div class="col-md-3">
                    <!--    Bordered Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Payment History
                        </div>
                        <!-- panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table"><!--display students payment history-->
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                                 <th>Student Name </th>
                                                    <th>Student Registration No </th>
                                            <th>Price</th>
                                            <th>Date </th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"Select * From payment");//select all data in payment table in database
$cnt=1;//counter start from 1
while($row=mysqli_fetch_array($sql))
{
?>

                                        <tr>
                                            <td><?php echo $cnt;?></td>
                                            <td><?php echo htmlentities($row['studentName']);?></td><!--display student name who paid-->
                                              <td><?php echo ($row['studentRegno']);?></td><!--display student registration no who paid-->								
                                            <td><?php echo htmlentities($row['price']);?></td><!--display the amount student paid-->
                                            <td><?php echo htmlentities($row['date']);?></td><!--display date-->
                                        </tr>
<?php 
$cnt++;//loop for counter to add itself
} ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	        </div>
    </div>
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<?php } ?>
<!--Code end-->
