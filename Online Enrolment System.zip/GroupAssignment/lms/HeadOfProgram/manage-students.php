<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
error_reporting(0);
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{



if(isset($_GET['del']))//when user press the delete button system will run this code to delete the specific data from database
      {
              mysqli_query($con,"delete from students where StudentRegno = '".$_GET['id']."'");//system will find the specific rows in database and delete it by using id of the data
                  $_SESSION['delmsg']="Student record deleted !!";// display this message when the data  is deleted successfully
      }

     if(isset($_GET['pass']))//when user press the reset password button system will run this code to reset student's password
      {
        $password="123";//this is the password the system will reset. Therefore, student's new password will be 123 after users press the reset password button
        $newpass=md5($password);// the new password will be replace the old password and save in database
              mysqli_query($con,"update students set password='$newpass' where StudentRegno = '".$_GET['id']."'");
                  $_SESSION['delmsg']="Password Reset. New Password is 123";// tell users password is updated and 123  is the new password.
      } 
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>HOP | Course</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Manage Student  </h1>
                    </div>
                </div>
                <div class="row" >
                 
                <font color="red" align="center"><?php echo htmlentities($_SESSION['delmsg']);?><?php echo htmlentities($_SESSION['delmsg']="");?></font>
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Manage Student
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Registration No </th>
                                            <th>Student Name </th>
                                            <th>Student Email </th>											
                                            <th> Pincode</th>
                                             <th>Register Date</th>
                                             <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"select * from students");//select data from students table
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>
 <tr>
   <td><?php echo $cnt;?></td>
   <td><?php echo htmlentities($row['StudentRegno']);?></td><!--display student registration no-->
   <td><?php echo htmlentities($row['studentName']);?></td><!--display student name-->
   <td><?php echo htmlentities($row['email']);?></td><!--display student email-->											
   <td><?php echo htmlentities($row['pincode']);?></td><!--display student pincode-->
   <td><?php echo htmlentities($row['creationdate']);?></td><!--display students' account creation date-->
   <td>
<a href="manage-students.php?id=<?php echo $row['StudentRegno']?>&del=delete" onClick="return confirm('Are you sure you want to delete?')"><!--display message for user to confirm whether they want to delete the student account or not-->
    <button class="btn btn-2">Delete</button><!--delte bbutton-->
</a>
<a href="manage-students.php?id=<?php echo $row['StudentRegno']?>&pass=update" onClick="return confirm('Are you sure you want to reset password?')"><!--display message for user to confirm whether they want to reset the password of students' account or not-->
<button type="submit" name="submit" id="submit" class="btn btn-1">Reset Password</button><!--reset password butto-->
</a>
   </td>
</tr>
<?php
$cnt++;//loop for counter to add itself
} ?>
</tbody>
</table>
 </div>
</div>
</div>
</div>
</div>
</div>
</div>
  <?php include('includes/footer.php');?><!--include header.php file to display header-->
</body>
</html>
<?php } ?>
<!--Code end-->
