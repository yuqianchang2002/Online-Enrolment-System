<?php
session_start();
include('includes/config.php');//include config.php file to connect to database
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>HOP | Enroll History</title>
    <link href="css/bootstrap.css" rel="stylesheet" /><!--connect to css files to use the class in the css files-->
    <link href="css/style.css" rel="stylesheet" /><!--connect to css files to use the class in the css files-->
</head>

<body>
<?php include('includes/header.php');?>    <!-- include header.php file to display header in this page-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar in this page 
}
 ?>
 <div class="content-wrapper"><!--content-wrapper-->
 <div class="container"><!--container-->
<div class="row"><!--row-->
<div class="col-md-3"><!--col-md-3-->
<h1 class="page-head-line">Enroll History  </h1> 
</div><!--col-md-3 section end-->
</div><!--row section end-->
<div class="row" ><!--row-->            
<div class="col-md-3"><!--col-md-3-->
<div class="panel panel-default"><!--panel default-->
<div class="panel-heading"><!--panel heading-->
Enroll History
</div><!--panel heading section end-->
<div class="panel-body"><!--panel body-->
<div class="table-responsive table-bordered"><!--table-responsive table-bordered-->
<table class="table"><!--Table to display enroll history-->
<thead>
     <tr>
        <th>#</th>
        <th>Student Name </th>
        <th>Student Registration No </th>
        <th>Course Name </th>
        <th>Semester</th>
       <th>Enrollment Date</th>
     </tr>
</thead>
<tbody>
<?php
$sql=mysqli_query($con,"select courseenrolls.course as cid, course.courseName as courname,semester.semester as sem,courseenrolls.enrollDate as edate ,students.studentName as sname,students.StudentRegno as sregno from courseenrolls join course on course.id=courseenrolls.course join semester on semester.id=courseenrolls.semester   join students on students.StudentRegno=courseenrolls.studentRegno ");//find data from courseenrolls and find the id from other table to display the actual data instead of dispplaying id
$cnt=1;//counter start from 
while($row=mysqli_fetch_array($sql))
{
?>

    <tr>
        <td><?php echo $cnt;?></td>
       <td><?php echo htmlentities($row['sname']);?></td>
        <td><?php echo htmlentities($row['sregno']);?></td>
          <td><?php echo htmlentities($row['courname']);?></td>
        <td><?php echo htmlentities($row['sem']);?></td>
		<td><?php echo htmlentities($row['edate']);?></td>
        <td>
          <a href="print.php?id=<?php echo $row['cid']?>" target="_blank">
         </td>
       </tr>
<?php 
$cnt++;
} ?>
</tbody>
</table><!--End of table-->
</div><!--table-responsive table-bordered sectionend-->
</div><!--panel body section end-->
</div><!--panel default section end-->
</div><!--col-md-3 section end-->
</div><!--row section end-->  
</div><!--container section end-->
</div><!--content-wrapper section end-->
	
  <?php include('includes/footer.php');?>    <!-- include footer.php file to display footer in this page -->
</body>
</html>
<?php } ?>
<!--End of the code-->