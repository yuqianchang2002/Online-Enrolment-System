<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                 <p>Learning Management System | By : Chang Yu Qian, Felix Hoi Man Yew, Lee Young Juin, Tan Yu Jie</p><!--copyright-->
                </div>

            </div>
        </div>
    </footer>