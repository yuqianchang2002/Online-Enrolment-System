<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{

if(isset($_POST['submit']))//system will run this code when users press the submit button
{
  $semester=$_POST['semester'];//define variable
$ret=mysqli_query($con,"insert into semester(semester) values('$semester')");//add data into semester table in database
if($ret)
{
$_SESSION['msg']="Semester Created Successfully !!";//display this message to users when semester added successfully
}
else
{
  $_SESSION['msg']="Error : Semester not created";//display this message to users when semester failed to add
}
}
if(isset($_GET['del']))//system will run this code when users press the delete button
      {
              mysqli_query($con,"delete from semester where id = '".$_GET['id']."'");//find the data by using id and delete it
                  $_SESSION['delmsg']="Semester deleted !!";//display this message to users when semester deleted successfully
      }
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>HOP | Semester</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Add/Delete Semester  </h1>
                    </div>
                </div>
                <div class="row" >
                  <div class="col-md-1"></div>
                    <div class="col-md-2">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           Semester 
                        </div>
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>


  <div class="panel-body">
  <form method="post"><!--add semester form-->
   <div class="form-group">
    <label for="department">Add Semester  </label>
    <input type="text" class="form-control" id="semester" name="semester" placeholder="Semester" required /><!--enter semester column-->
  </div>
 <button type="submit" name="submit" class="btn btn-1">Submit</button> <!--submit butto-->
</form>
</div>
</div>
</div>                  
</div>
<font color="red" align="center"><?php echo htmlentities($_SESSION['delmsg']);?><?php echo htmlentities($_SESSION['delmsg']="");?></font><!--display message here-->
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Manage Semester
                        </div>                        
						<div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table"><!--Display semester-->
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Semester</th>
                                            <th>Creation Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"select * from semester");//select all data from semester table in database
$cnt=1;//counter start from 1
while($row=mysqli_fetch_array($sql))
{
?>
                                        <tr>
                                            <td><?php echo $cnt;?></td><!--display counter-->
                                            <td><?php echo htmlentities($row['semester']);?></td><!--display semester-->
                                            <td><?php echo htmlentities($row['creationDate']);?></td><!--display semester creation date-->
                                            <td>
  <a href="semester.php?id=<?php echo $row['id']?>&del=delete" onClick="return confirm('Are you sure you want to delete?')"><!--display message for user to confirm whether they want to delete the data or not-->
                                            <button class="btn btn-2">Delete</button><!--delete button-->
  </a>
                                            </td>
                                        </tr>
<?php 
$cnt++;//loop for counter add itself to count the number of data
} ?>

                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<?php } ?>
<!--Code end-->
