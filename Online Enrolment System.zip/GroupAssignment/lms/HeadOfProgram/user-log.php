<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{

?>

<html>
<head>
    <meta charset="utf-8" />
    <title>HOP | StudentLog</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>
<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Student Login History  </h1>
                    </div>
                </div>
                <div class="row" >
            
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Student Login History
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table"><!--table to display userlog information-->
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Student Reg no </th>
                                            <th>Login Time </th>
                                             <th>Logout Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"select * from userlog");//get all data from userlog
$cnt=1;//counter start from 1
while($row=mysqli_fetch_array($sql))
{
?>


                                        <tr>
                                            <td><?php echo $cnt;?></td><!--display counter-->
                                              <td><?php echo htmlentities($row['studentRegno']);?></td><!--display student registration no from userlog table-->
                                            <td><?php echo htmlentities($row['loginTime']);?></td><!--display student login time from userlog table-->
                                            <td><?php echo htmlentities($row['logout']);?></td><!--display student logout time  from userlog table-->
                                        </tr>
<?php 
$cnt++;//counter can add itself to display the number of data
} ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<?php } ?>
<!--Code end-->