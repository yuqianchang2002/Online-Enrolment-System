<?php
session_start();
error_reporting(0);
include("includes/config.php");// include config.php file to connect the database
if(isset($_POST['submit']))// run this code when user press the login button
{
//define variable in index page
    $username=$_POST['username'];
    $password=md5($_POST['password']);
$query=mysqli_query($con,"SELECT * FROM headofprogram WHERE username='$username' and password='$password'");
$num=mysqli_fetch_array($query);
if($num>0)
{
$extra="change-password.php";//log in to change password page in headofprogram page
$_SESSION['alogin']=$_POST['username'];
$_SESSION['id']=$num['id'];
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
else
{
$_SESSION['errmsg']="Invalid username or password";
$extra="index.php";
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
}
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>HOP |  Login</title> <!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>
<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<div class="content-wrapper"><!--content-wrapper-->
<div class="container"><!--container-->
<div class="row"><!--row-->
<div class="col-md-3"><!--col-md-3-->
    <h4 class="page-head-line">Please Login To Enter </h4>
</div><!--col-md-3 section end-->
</div><!--row section end-->
<span style="color:red;" ><?php echo htmlentities($_SESSION['errmsg']); ?><?php echo htmlentities($_SESSION['errmsg']="");?></span>
<form method="post"><!--User input username and password form-->
<div class="row"><!--row-->
<div class="col-md-2"><!--col-md-2-->
    <label>Enter Username : </label>
    <input type="text" name="username" class="form-control" required /><!--input username field-->
    <label>Enter Password :  </label>
   <input type="password" name="password" class="form-control" required /><!--input password field-->
    <hr />
     <button type="submit" name="submit" class="btn btn-1"> &nbsp;Log In </button>&nbsp;<!--login button-->
</div><!--col-md-2 section end-->
</form><!--User input username and password form section end-->
<img src="https://newinti.edu.my/wp-content/uploads/2020/08/intistar.jpg"alt="Inti Logo"style="width:150px;height100px"></p><!--INTI logo-->
</div><!--row section end-->
<form method="POST" action="http://localhost/GroupAssignment/lms/lecturer/index.php">
<button type="submit" name="submit" class="btn btn-1"/> &nbsp;Lecturer Login</button>&nbsp; <!--user can press this button to lecturer's login page -->
</form>			
</div><!--container section end-->
</div><!--content-wrapper section end-->
 <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<!--Code end-->
