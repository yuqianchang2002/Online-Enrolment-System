<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{

if(isset($_POST['submit']))//when user press the submit button system will run these codes
{
//define variable in course.php page
$coursecode=$_POST['coursecode'];
$coursename=$_POST['coursename'];
$coursePrice=$_POST['coursePrice'];
$status=$_POST['status'];
$ret=mysqli_query($con,"insert into course(courseCode,courseName,coursePrice,status) values('$coursecode','$coursename','$coursePrice','$status')");//insert data into database
if($ret)
{
$_SESSION['msg']="Course Created Successfully !!";//dispplay the message to users when course created successfully
}
else
{
  $_SESSION['msg']="Error : Course not created";//dispplay the message to users when course did not create successfully
}
}
if(isset($_GET['del']))//when user press the delete button system will run this code
      {
              mysqli_query($con,"delete from course where id = '".$_GET['id']."'");//delete the course by finding the id in the table in database(myphpAdmin)
                  $_SESSION['delmsg']="Course deleted !!";//display this message when course is deleted
      }
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>HOP | Course</title><!--Page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include header.php file to display menubar
} ?>
    <div class="content-wrapper"><!--content-wrapper-->
        <div class="container"><!--container-->
              <div class="row"><!--row-->
                    <div class="col-md-3"><!--col-md-3 -->
                        <h1 class="page-head-line">Add/Delete Course  </h1>
                    </div><!--row section end-->
                </div><!--col-md-3 section end-->
                <div class="row" ><!--row-->
                  <div class="col-md-1"></div><!-- to display the table in center -->
                    <div class="col-md-2"><!--col-md-2 -->
                        <div class="panel panel-default"><!--panel default -->
                        <div class="panel-heading"><!--panel heading -->
                           Add Course 
                        </div><!--panel heading section end -->
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font><!--Display message in green color font-->
   <div class="panel-body"><!--panel body-->
   <form method="post"><!--Add new course form-->
   <div class="form-group"><!--form group-->
    <label for="coursecode">Course Code  </label>
    <input type="text" class="form-control" id="coursecode" name="coursecode" placeholder="Course Code" required /><!--field to input course code-->
  </div><!--form group section end-->

 <div class="form-group"><!--form group-->
    <label for="coursename">Course Name  </label>
    <input type="text" class="form-control" id="coursename" name="coursename" placeholder="Course Name" required /><!--field to input course name-->
  </div><!--form group section end-->

<div class="form-group"><!--form group-->
    <label for="coursePrice">Price  </label>
    <select class="form-control" name="coursePrice" id="coursePrice" onBlur="courseAvailability()" required="required"><!--selection column for user to choose price-->
   <option value="coursePrice">Course Price</option>   
   <?php 
$sql=mysqli_query($con,"select * from price");
while($row=mysqli_fetch_array($sql))
{
?>
<option value="<?php echo htmlentities($row['price']);?>"><?php echo htmlentities($row['price']);?></option>
<?php } ?>
    </select> <!--selection column section end-->
  </div> <!--form group section end--> 

<div class="form-group"><!--form group-->
    <label for="status">Course Status  </label>
    <input type="text" class="form-control" id="status" name="status" placeholder="Course Status" required /><!--field to input course status-->
  </div><!--form group section end-->

 <button type="submit" name="submit" class="btn btn-1">Submit</button><!--Submit button to add course after inpputing-->
</form><!--form section end-->
</div><!--panel default section end-->
</div><!--col-md-2 section end-->
</div><!--row section end-->          
</div><!--container section end-->

<font color="red" align="center"><?php echo htmlentities($_SESSION['delmsg']);?><?php echo htmlentities($_SESSION['delmsg']="");?></font>
<div class="col-md-3"><!--col-md-3 -->
<div class="panel panel-default"><!--panel default-->
<div class="panel-heading"><!--panel heading-->
    Manage Course
</div><!--panel heading section end-->
<div class="panel-body"><!--panel body-->
<div class="table-responsive table-bordered"><!--bordered table-->
<table class="table"><!--table to dplay added courses-->
<thead>
 <tr>
     <th>#</th>
     <th>Course Code</th>
     <th>Course Name </th>
     <th>Course Price</th>
     <th>Course Status</th>
     <th>Creation Date</th>
     <th>Action</th>
   </tr>
 </thead
<tbody>
<?php
$sql=mysqli_query($con,"select * from course");//select all data from course table
$cnt=1;//counter start from 1
while($row=mysqli_fetch_array($sql))
{
?><tr>
  <td><?php echo $cnt;?></td><!--counter-->
  <td><?php echo htmlentities($row['courseCode']);?></td><!--display course code-->
  <td><?php echo htmlentities($row['courseName']);?></td><!--display course name-->
  <td><?php echo htmlentities($row['coursePrice']);?></td><!--display course price-->
   <td><?php echo htmlentities($row['status']);?></td><!--display course status-->
  <td><?php echo htmlentities($row['creationDate']);?></td><!--display course creation date-->
  <td>
  <a href="edit-course.php?id=<?php echo $row['id']?>"><!--find specific course to edit by filtering its id-->  
<button class="btn btn-1"> Edit</button> </a><!--edit button-->                                        
  <a href="course.php?id=<?php echo $row['id']?>&del=delete" onClick="return confirm('Are you sure you want to delete?')"><!--find specific course to delet by filtering its id and send a confirm message for user to confirm-->  
   <button class="btn btn-2">Delete</button><!--Delete button-->
</a>
  </td>
 </tr>
<?php 
$cnt++;//loop for counter to add
} ?>                                        
</tbody>
</table><!--table to display added courses end-->
</div><!--bordered table section end-->
</div><!--panel body section end-->
</div><!--panel heading section end-->
</div><!--col-md-3 section end-->
</div><!--container section end-->
</div><!--contain wrapper section end-->
</div>
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<?php } ?>
<!--Code end-->