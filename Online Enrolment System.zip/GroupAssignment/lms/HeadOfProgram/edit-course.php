<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
$id=intval($_GET['id']);
date_default_timezone_set('Asia/Kuala_Lumpur');//Kuala Lumpurtimezone
$currentTime = date( 'Y-m-d H:i:s ', time ()  );//exp output: 2021-8-31- 18:33

if(isset($_POST['submit']))//if user click the updat button system will run this code
{
//defile variable in  edit course page
$coursecode=$_POST['coursecode'];
$coursename=$_POST['coursename'];
$coursePrice=$_POST['coursePrice'];
$status=$_POST['status'];
$ret=mysqli_query($con,"update course set courseCode='$coursecode',courseName='$coursename',coursePrice='$coursePrice',status='$status',updationDate='$currentTime' where id='$id'");//update the data in database
if($ret)
{
$_SESSION['msg']="Course Updated Successfully !!";//inform users when updated successfully
}
else
{
  $_SESSION['msg']="Error : Course not Updated";//inform users when updat fail
}
}
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>HOP | Edit Course</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
    <!-- LOGO HEADER END-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper"><!--content-wrapper-->
        <div class="container"><!--container-->
              <div class="row"><!--row-->
                    <div class="col-md-3"><!--col-md-3 -->
                        <h1 class="page-head-line">Edit Course  </h1>
                    </div><!--col-md-3 section end-->
                </div><!--row section end-->
                <div class="row" ><!--row-->
                  <div class="col-md-1"></div><!--to display the table  in center-->
                    <div class="col-md-2"><!--col-md-2 -->
                        <div class="panel panel-default"><!--panel default -->
                        <div class="panel-heading"><!--panel heading -->
                           Course 
                        </div><!--panel heading section end -->
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>


<div class="panel-body"><!--panel body-->
<form method="post"><!--edit course form-->
<?php
$sql=mysqli_query($con,"select * from course where id='$id'");//select specific rows from database by using id
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>
<p><b>Last Updated at</b> :<?php echo htmlentities($row['updationDate']);?></p><!--display last updation date-->
   <div class="form-group"><!--form group-->
    <label for="coursecode">Course Code  </label>
    <input type="text" class="form-control" id="coursecode" name="coursecode" placeholder="Course Code" value="<?php echo htmlentities($row['courseCode']);?>" required /><!--input course code-->
  </div><!--form group section end-->

 <div class="form-group"><!--form group-->
    <label for="coursename">Course Name  </label>
    <input type="text" class="form-control" id="coursename" name="coursename" placeholder="Course Name" value="<?php echo htmlentities($row['courseName']);?>" required /><!--input course name-->
  </div><!--form group section end-->

<div class="form-group"><!--form group-->
    <label for="coursePrice">Price  </label>
    <select class="form-control" name="coursePrice" id="coursePrice" onBlur="courseAvailability()" required="required">
   <option value="coursePrice">Course Price</option>   
   <?php 
$sql=mysqli_query($con,"select * from price");
while($row=mysqli_fetch_array($sql))
{
?>
<option value="<?php echo htmlentities($row['price']);?>"><?php echo htmlentities($row['price']);?></option>
<?php } ?>
    </select> 
  </div><!--form group section end-->
  
<div class="form-group"><!--form group-->
    <label for="status">Course Status  </label>
    <input type="text" class="form-control" id="status" name="status" placeholder="Course Status" value="<?php echo htmlentities($row['status']);?>" required />
  </div>  <!--form group section end-->


<?php } ?>
 <button type="submit" name="submit" class="btn btn-1"> Update</button> <!--update button-->
</form><!--edit course form end-->
</div><!--panel body section end-->
</div><!--form group section end-->
</div><!--panel default section end-->
</div><!--col-md-2 section end-->
</div><!--row section end-->
</div><!--container section end-->
</div><!--content-wrapper section end-->
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<?php } ?>
<!--Code end-->
