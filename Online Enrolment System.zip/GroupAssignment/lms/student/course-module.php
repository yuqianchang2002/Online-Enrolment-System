<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
error_reporting(0);
if(strlen($_SESSION['login'])==0)
    {   
header('location:index.php');
}
else{

?>
<html>
<head>
    <meta charset="utf-8" />
    <title>Student | Courses Module </title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['login']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <div class="content-wrapper"
        <div class="container">
          <div class="row">
          <div class="col-md-3">
           <h1 class="page-head-line">Courses Modules </h1>
          </div>
          </div>
          <div class="row" >
          <div class="col-md-3">
          <div class="panel panel-default">
          <div class="panel-heading">
             Courses Modules 
          </div>
          <div class="panel-body">
          <div class="table-responsive table-bordered">
          <table class="table"><!--table to display course module-->
             <thead>
               <tr>
                <th>#</th>
				<th>File Name</th>
                <th>Course Name </th>
				<th>Download</th>
                </tr>
                </thead>
                                   
				<tbody>
				<tr>
				 <td>1</td>
				 <td>Objected-Oriented Programming Past Year Exam Paper</td>
				 <td>Objected Oriendted Programming</td>
				 <td>
				 <a href="course-module\2019Jan.pdf" download="Objected-Oriented Programming Past Year Paper"><!--file location and file name when download-->
				 <button class="btn btn-1"> Download</button></a> <!--download button-->                                          
				 </td>
                </tr>
			
				<tr>
				 <td>2</td>
				 <td>Introduction to Internet Technology Chap01 Notes</td>
				 <td>Introduction to Internet Technology</td>
				 <td>
				 <a href="course-module\DTI5e_Ch01_PPT.pptx" download="Introduction to Internet Technology Chap01 Notes"><!--file location and file name when download-->
				 <button class="btn btn-1"> Download</button></a><!--Download Button-->                                             
				</td>
                </tr>

				<tr>
				 <td>3</td>
				 <td>Introduction to Mobile Apps Development Chap01 Notes</td>
				 <td>Introduction to Mobile Apps Development</td>
				 <td>
				 <a href="course-module\IntroductiontoMobileAppsDevelopment.pdf" download="Introduction to Mobile Apps Development Chap01 Notes"><!--file location and file name when download-->
				 <button class="btn btn-1"> Download</button></a> <!--Download Button-->                                            
				 </td>
                </tr>
									
				<tr>
				 <td>4</td>
				 <td>ICT2108 Assigment 1</td>
				 <td>Introduction to Digital Image Editing</td>
				 <td>
				 <a href="course-module\ICT2108 Assgn 1.doc" download="ICT2108 Assigment 1"><!--file location and file name when download-->
				 <button class="btn btn-1"> Download</button></a> <!--Download Button-->                                            
				 </td>
                 </tr				 
				<tr>
					<td>5</td>
					<td>ICT2108 Assigment 1 rubric</td>
					<td>Introduction to Digital Image Editing</td>
					<td>
					<a href="course-module\ICT2108 Assignment 1 Rubrics.pdf" download="ICT2108 Assigment 1 rubric"><!--file location and file name when download-->
					<button class="btn btn-1"> Download</button></a><!--Download Button-->                                             
					</td>
                   </tr>
                                       
				<tr>
					<td>6</td>
					<td>ICT2108 Assigment 2</td>
					<td>Introduction to Digital Image Editing</td>
					<td>
					<a href="course-module\ICT2108 Assgn 2.doc" download="ICT2108 Assigment 2"><!--file location and file name when download-->
					<button class="btn btn-1"> Download</button></a><!--Download Button-->                                             
					</td>
                 </tr>

				<tr>
					<td>7</td>
					<td>ICT2108 Assigment 2 rubric</td>
					<td>Introduction to Digital Image Editing</td>
					<td>
					<a href="course-module\ICT2108 Assignment 1 Rubrics.pdf" download="ICT2108 Assigment 2 rubric"><!--file location and file name when download-->
					<button class="btn btn-1"> Download</button></a> <!--Download Button-->                                            
					</td>
                 </tr>
				
				<tr>
					<td>8</td>
					<td>IBM 2104 Lab Assignment</td>
					<td>Introduction to Web Programming with PHP</td>
					<td>
					<a href="course-module\IBM2104 Lab Assignment 1.pdf" download="IBM 2104 Lab Assignment"><!--file location and file name when download-->
					<button class="btn btn-1"> Download</button></a><!--Download Button-->                                             
					</td>
                 </tr>
				 
				 <t>
 					<td>9</td>
					<td>Introduction to Database Chap01 Notes</td>
					<td>Introduction to Database</td>
					<td>
					<a href="course-module\CHAP_1 DATABASE SYSTEM(1).pptx" download="Introduction to Database Chap01 Notes"><!--file location and file name when download-->
					<button class="btn btn-1"> Download</button></a><!--Download Button-->                                             
					</td>
                  </tr>
 				  
				  <tr> 
 					<td>10</td>
					<td>Fundamental of Management Chap01 Notes</td>
					<td>Fundamental of Management</td>
					<td>
					<a href="course-module\robbins_mgmt14_ppt_01.pptx" download="Fundamental of Management Chap01 Notes"><!--file location and file name when download-->
					<button class="btn btn-1"> Download</button></a><!--Download Button-->                                           
					</td>
                 </tr>
 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</body>
</html>
<?php } ?>
