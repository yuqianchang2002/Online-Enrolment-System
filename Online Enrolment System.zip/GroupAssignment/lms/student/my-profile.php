<?php
session_start();
include('includes/config.php');// link config.php file to connect database
error_reporting(0);
if(strlen($_SESSION['login'])==0)
    {   
header('location:index.php');
}
else{

if(isset($_POST['submit']))//system will run this code once users press the update button
{
$studentname=$_POST['studentname'];
$email=$_POST['email'];
$ret=mysqli_query($con,"update students set studentName='$studentname',email='$email'  where StudentRegno='".$_SESSION['login']."'");//system will find and update students information in the database
if($ret)
{
$_SESSION['msg']="Student Record updated Successfully !!";//inform users his/her profile is updated
}
else
{
  $_SESSION['msg']="Error : Student Record not update";//inform users his/her profile is not updated
}
}
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Student | MyProfile</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['login']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar-->
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">My Profile  </h1>
                    </div>
                </div>
                <div class="row" >
                  <div class="col-md-1"></div>
                    <div class="col-md-2">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                          Profile
                        </div>
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>
<?php $sql=mysqli_query($con,"select * from students where StudentRegno='".$_SESSION['login']."'");//select specific data from students table according to the log in user
$cnt=1;
while($row=mysqli_fetch_array($sql))
{ ?>

<div class="panel-body">
<form method="post" enctype="multipart/form-data"><!--update profile form-->
   <div class="form-group">
    <label for="studentname">Student Name  </label>
    <input type="text" class="form-control" id="studentname" name="studentname" value="<?php echo htmlentities($row['studentName']);?>"  /><!--enter student name field-->
  </div>

 <div class="form-group">
    <label for="studentregno">Student Registration No  </label>
    <input type="text" class="form-control" id="studentregno" name="studentregno" value="<?php echo htmlentities($row['StudentRegno']);?>"  placeholder="Student Reg no" readonly /><!--display student registration no field-->
    
  </div>
  
<div class="form-group">
    <label for="Pincode">Pincode  </label>
    <input type="text" class="form-control" id="Pincode" name="Pincode" readonly value="<?php echo htmlentities($row['pincode']);?>" required /><!--display student pincode field-->
  </div>   

<div class="form-group">
    <label for="email">Email  </label>
    <input type="text" class="form-control" id="email" name="email"  value="<?php echo htmlentities($row['email']);?>" required /><!--enter student email field-->
  </div>  
  <?php } ?>

 <button type="submit" name="submit" id="submit" class="btn btn-1">Update</button><!--update button-->
</form>
                            </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<?php } ?>
<!--code end-->