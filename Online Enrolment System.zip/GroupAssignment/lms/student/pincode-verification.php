
<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
error_reporting(0);
if(strlen($_SESSION['login'])==0)
    {   
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kuala_Lumpur');//Kuala Lumpur time
$currentTime = date( 'Y-m-d H:i:s ', time ()  );//exp output: 2021-11-30 15:33
if(isset($_POST['submit']))//system will run this code when user press the verify button
{
$sql=mysqli_query($con,"SELECT * FROM  students where pincode='".trim($_POST['pincode'])."' && StudentRegno='".$_SESSION['login']."'");//select pincode data from the students table according to the log in user
$num=mysqli_fetch_array($sql);
if($num>0)
{
$_SESSION['pcode']=$_POST['pincode'];
header("location:enroll.php");
}
else
{
$_SESSION['msg']="Error :Wrong Pincode. Please Enter a Valid Pincode !!";//display when users enter the wrong pincode
}
}
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Student | Pincode Verification</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['login']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Student Pincode Verification</h1>
                    </div>
                </div>
                <div class="row" >
                  <div class="col-md-1"></div>
                    <div class="col-md-2">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                          Pincode Verification
                        </div>
<font color="red" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>
 <div class="panel-body">
<form method="post"><!--pincode verification form-->
   <div class="form-group">
    <label for="pincode">Enter Pincode</label>
    <input type="password" class="form-control" id="pincode" name="pincode" placeholder="Pincode" required /><!--enter pincode form-->
	<p>Students can refer the "My Profile" page to check their pincode."</p>
  </div>
  <button type="submit" name="submit" class="btn btn-1">Verify</button><!--verify button-->
                           <hr />
</form>
                            </div>
                            </div>
                    </div>
                </div>
        </div>
    </div>
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<?php } ?>
<!--code end-->