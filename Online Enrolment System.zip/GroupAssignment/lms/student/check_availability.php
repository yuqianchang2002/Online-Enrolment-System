<?php session_start();
require_once("includes/config.php");//link config.php file
if(!empty($_POST["courseName"])) {
$courseName= $_POST["courseName"];
 $regid=$_SESSION['login'];
 $result =mysqli_query($con,"SELECT studentRegno FROM courseenrolls WHERE course='$courseName' and studentRegno=' $regid'");
	$count=mysqli_num_rows($result);
if($count>0)//check student whether the student got apply for this course before or not
{
echo "<span style='color:red'> Already Applied for this course.</span>";//if student already enrolled this course system will display this message
 echo "<script>$('#submit').prop('disabled',true);</script>";
} 
else if ($count<6 && $count>0){//if check how many course students enrolled
echo "<span style='color:red'> You can only enroll 5 courses!</span>";//if student already enrolled 5 or more course system will display this message
}
}
if(!$status="Active") {//check the course status
	$courseName= $_POST["courseName"];
		$result =mysqli_query($con,"SELECT * FROM courseenrolls WHERE course='$courseName'");//select all data from courseenrolls
		$count=mysqli_num_rows($result);
		$result1 =mysqli_query($con,"SELECT status FROM course WHERE id='$courseName'");//select all data from course
		$row=mysqli_fetch_array($result1);
		$status=$row['status'];
if($status="Full")
{
echo "<span style='color:red'> Seat not available for this course. All Seats Are full</span>";//if the course status is full system will decline students request and display this message
 echo "<script>$('#submit').prop('disabled',true);</script>";
} 
}

?>
