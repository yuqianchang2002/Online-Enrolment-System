<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
error_reporting(0);
if(strlen($_SESSION['login'])==0)
    {   
header('location:index.php');
}
else{



?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Student | Payment</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['login']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Payment  </h1>
                    </div>
                </div>
                <div class="row" >            
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Course details and prices
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Course Name </th>
                                            <th> Semester</th>
                                             <th>Price</th>
                                             <th>Enrollment Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"select courseenrolls.course as cid, course.courseName as courname,semester.semester as sem,price.price as price, courseenrolls.enrollDate as edate from courseenrolls join course on course.id=courseenrolls.course join semester on semester.id=courseenrolls.semester join price on price.id=courseenrolls.price where courseenrolls.studentRegno='".$_SESSION['login']."'");//find data from courseenrolls and find the id from other table to display the actual data instead of dispplaying id
$cnt=1;//counter to count the number of data and display
while($row=mysqli_fetch_array($sql))
{
?>
                                        <tr>
                                            <td><?php echo $cnt;?></td><!--display counter-->
                                            <td><?php echo htmlentities($row['courname']);?></td><!--display course name-->
                                            <td><?php echo htmlentities($row['sem']);?></td><!--display semester-->
                                            <td><?php echo htmlentities($row['price']);?></td><!--display price-->
                                            <td><?php echo htmlentities($row['edate']);?></td><!--display enrolment date-->
                                        </tr>
<?php 
$cnt++;
} ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
		<!--  Make Payment  -->
		<?php
		if(isset($_POST['submit']))//systen will  run this code when users press the pay button
{
//define variable
$studentName=$_POST['studentName'];
$studentregno=$_POST['studentregno'];
$price=($_POST['price']);
$month=$_POST['month'];
$ret=mysqli_query($con,"insert into payment(StudentRegno,studentName,price,month) values('$studentregno','$studentName','$price','$month')");//insert data to payment table indatabase
if($ret)
{
echo "<Payment Successfully !!";//inform users the payment is success
}
else
{
  echo "Error : Payment Failed";///inform users the payment is fail
}
}
?>
		<form action="Payment.php" method="post"><!--payment form-->
		<label for="studentName">Enter Name:</label>
		<input type ="text" name="studentName" class="form-control" id="studentName"><!--enter student name field-->	
		<label for="studentregno">Enter Registration No:</label>
		<input type ="text" name="studentregno" class="form-control" id="studentregno" required><!--enter student name field-->	
		<label for="NameOnCard">Enter Name on Card:</label>
		<input type ="text" name="NameOnCard" class="form-control" id="NameOnCard">	<!--enter name on card field-->	
		<label for="cardno">Enter Card Number:</label>
		<input type ="text" name="cardno" class="form-control" id="cardno">	<!--enter card number field-->	
		<label for="price">Enter Amount:</label>
		<input type ="text" name="price" class="form-control" id="price" required><!--enter pay amountfield-->	
		<label for="month">Enter Month:</label>
		<input type ="text" name="month" class="form-control" id="month" required><!--enter month field-->	
		<!--example for user to  input the month-->
		<p>Please enter the month of the date(exp:"January","February","March","April","May","June","July","August","September","October","November","December")</p>
		<hr/>
		<button type="submit" name="submit" class="btn btn-1"/>&nbsp;Pay&nbsp;</button><!--pay button-->
		</div>
	</form>
                </div>
            </div>
        </div>
    </div>
                </div>
            </div>
	        </div>
    </div>
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<?php } ?>
<!--code end-->