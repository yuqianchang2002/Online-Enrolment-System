<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
error_reporting(0);
if(strlen($_SESSION['login'])==0)
    {   
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kuala_Lumpur');//Kuala Lumpur Timezone
$currentTime = date( 'Y-m-d H:i:s ', time ()  );//exp output: 2021-8-31- 18:33


if(isset($_POST['submit']))//system will run the following code after users press the submit button
{
$sql=mysqli_query($con,"SELECT password FROM  students where password='".md5($_POST['cpass'])."' && studentRegno='".$_SESSION['login']."'");//find current password
$num=mysqli_fetch_array($sql);
if($num>0)
{
 $con=mysqli_query($con,"update students set password='".md5($_POST['newpass'])."', updationDate='$currentTime' where studentRegno='".$_SESSION['login']."'");//update new password
$_SESSION['msg']="Password Changed Successfully !!";//inform users when password changed successfully
}
else
{
$_SESSION['msg']="Current Password not match !!";//inform users when current password is wrong
}
}
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Student | Change Password</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>
<script type="text/javascript">//using javascript language to check whether the password field is empty or user already input data
function valid()
{
if(document.chngpwd.cpass.value=="")//check current password field
{
alert("Current Password Filed is Empty !!");//system will display this message if current password field is empty
document.chngpwd.cpass.focus();
return false;
}
else if(document.chngpwd.newpass.value=="")//check new password field
{
alert("New Password Filed is Empty !!");//system will display this message if new password field is empty
document.chngpwd.newpass.focus();
return false;
}
else if(document.chngpwd.cnfpass.value=="")//check confirm password field
{
alert("Confirm Password Filed is Empty !!");//system will display this message if confirm password field is empty
document.chngpwd.cnfpass.focus();
return false;
}
else if(document.chngpwd.newpass.value!= document.chngpwd.cnfpass.value)//check new password and confirm password field
{
alert("Password and Confirm Password Field do not match  !!");//system will display this message when the data in new password and confirm password field not match
document.chngpwd.cnfpass.focus();
return false;
}
return true;
}
</script><!--javascript language end here-->
<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
    <!-- LOGO HEADER END-->
<?php if($_SESSION['login']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Student Change Password </h1>
                    </div>
                </div>
                <div class="row" >
                  <div class="col-md-1"></div>
                    <div class="col-md-2">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           Change Password
                        </div>
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font><!--display message which font is green color-->

<div class="panel-body">
   <form method="post" onSubmit="return valid();"><!--change password form--> 
   <div class="form-group">
    <label for="exampleInputPassword1">Current Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" name="cpass" placeholder="Password" /><!--input current password field--> 
  </div>
   <div class="form-group">
    <label for="exampleInputPassword1">New Password</label>
    <input type="password" class="form-control" id="exampleInputPassword2" name="newpass" placeholder="Password" /><!--input new password field--> 
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Confirm Password</label>
    <input type="password" class="form-control" id="exampleInputPassword3" name="cnfpass" placeholder="Password" /><!--input confirm password field--> 
  </div>
  <button type="submit" name="submit" class="btn btn-1">Submit</button><!--submit button-->
 <hr />
</form><!--change password form end-->
</div>
</div>
 </div>
 </div>
 </div>
</div>
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<?php } ?>
<!--code end-->
