<?php
session_start();
include('includes/config.php');//link config.php file
error_reporting(0);
if(strlen($_SESSION['login'])==0)
    {   
header('location:index.php');
}
else{



?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Student | Enrolled Courses </title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['login']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Enrolled Courses  </h1>
                    </div>
                </div>
                <div class="row" >            
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Enrolled Courses 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table"><!--tale to display enrolled courses-->
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Course Name </th>
                                            <th> Semester</th>
                                             <th>Enrollment Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"select courseenrolls.course as cid, course.courseName as courname,semester.semester as sem,courseenrolls.enrollDate as edate from courseenrolls join course on course.id=courseenrolls.course join semester on semester.id=courseenrolls.semester where courseenrolls.studentRegno='".$_SESSION['login']."'");//find data from courseenrolls and find the id from other table to display the actual data instead of dispplaying id
$cnt=1;//counter start from 1
while($row=mysqli_fetch_array($sql))
{
?>

                                        <tr>
                                            <td><?php echo $cnt;?></td><!--display number of data-->
                                            <td><?php echo htmlentities($row['courname']);?></td><!--display enrolled course name-->
                                            <td><?php echo htmlentities($row['sem']);?></td><!--display semester-->
                                             <td><?php echo htmlentities($row['edate']);?></td><!--display enrolment date-->
                                        </tr>
<?php 
$cnt++;//loop for counter to count the number of data
} ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<?php } ?>
<!--code end-->