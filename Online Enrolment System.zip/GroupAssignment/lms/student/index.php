<?php
session_start();
error_reporting(0);
include("includes/config.php");//link config.php file
if(isset($_POST['submit']))//code will be run when users press the login button
{
//define variable
    $regno=$_POST['regno'];
    $password=md5($_POST['password']);
$query=mysqli_query($con,"SELECT * FROM students WHERE StudentRegno='$regno' and password='$password'");//select specific data from studentstable 
$num=mysqli_fetch_array($query);
if($num>0)
{
$extra="change-password.php";
$_SESSION['login']=$_POST['regno'];
$_SESSION['id']=$num['studentRegno'];
$_SESSION['sname']=$num['studentName'];
$uip=$_SERVER['REMOTE_ADDR'];
$status=1;
$log=mysqli_query($con,"insert into userlog(studentRegno) values('".$_SESSION['login']."')");
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
else
{
$_SESSION['errmsg']="Invalid Student or Password";
$extra="index.php";
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
}
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Student | Login</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootstrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>
<body>
    <?php include('includes/header.php');?><!--include header.php file to display header-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h4 class="page-head-line">Student Login Page</h4>
                </div>
            </div>
             <span style="color:red;" ><?php echo htmlentities($_SESSION['errmsg']); ?><?php echo htmlentities($_SESSION['errmsg']="");?></span>
            <form method="post"><!--login form-->
            <div class="row">
                <div class="col-md-2">
                     <label>Enter Student Registration No : </label>
                        <input type="text" name="regno" class="form-control"  /><!--Enter student registration no field-->
                        <label>Enter Password :  </label>
                        <input type="password" name="password" class="form-control"  /><!--Enter student registration no field-->
                        <hr />
                        <button type="submit" name="submit" class="btn btn-1">&nbsp;Log In </button>&nbsp;<!--login button-->
						
				</div>
                </form>
				<img src="https://newinti.edu.my/wp-content/uploads/2020/08/intistar.jpg"alt="Inti Logo"style="width:150px;height100px"></p><!--INTI logo-->

				<form method="POST" action="register.php">
				 	<button type="submit" name="submit" class="btn btn-1"/>&nbsp;Register&nbsp;</button><!--student  register button to lead users to the register page-->
				</form>
				<form method="POST" action="http://localhost/GroupAssignment/lms/headofprogram/index.php">
      				<button type="submit" name="submit" class="btn btn-1"/> &nbsp;HOP Login</button>&nbsp;<!--HOP login button to lead users to the HOP login page-->
				</form>	
				<form method="POST" action="http://localhost/GroupAssignment/lms/lecturer/index.php">
      				<button type="submit" name="submit" class="btn btn-1"/> &nbsp;Lecturer Login</button>&nbsp;<!--lecturer login button to lead users to the lecturer login page-->
				</form>			

		
                </div>
            </div>
        </div>
    </div>
    <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
</body>
</html>
<!--code end-->