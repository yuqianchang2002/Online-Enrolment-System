<?php 

session_start();


if(isset($_POST['submit']))//system will run this code when user press the register button
{
//define variable
$studentname=$_POST['studentname'];
$studentregno=$_POST['studentregno'];
$email=$_POST['email'];
$password=md5($_POST['password']);
$pincode = rand(100000,999999);//auto generate number between 100000 and 999999
$ret=mysqli_query($con,"insert into students(studentName,StudentRegno,password,pincode,email) values('$studentname','$studentregno','$password','$pincode','$email')");//insert data  into students table
if($ret)
{
$_SESSION['msg']="Student Registered Successfully !!";//inform user he/she is register successfully
}
else
{
  $_SESSION['msg']="Error : Student  not Register";//inform user he/she is dail register
}
}
?>
<html>
<head>
    <meta charset="utf-8" />
    <title>Student | Registration</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>
<body>

	 <div class="content-wrapper">
     <div class="container">
     <div class="row">
        <div class="col-md-2">
	<h1>Register</h1>
	<form action="register.php" method="post"><!--register form-->
		<label for="studentname">Enter Name:</label>
		<input type ="text" name="studentname" class="form-control" id="studentname" placeholder="Name"><!--enter student name field-->	
		<label for="studentregno">Enter Student Registration No:</label>
		<input type ="text" name="studentregno" class="form-control" id="studentregno" placeholder="Student Registration No"required><!--enter student reg no field-->	
		<label for="email">Enter email:</label>
		<input type ="text" name="email" class="form-control" id="email" placeholder="Email"required><!--enter student email field-->			
		<label for="password">Enter Password:</label>
		<input type ="text" name="password" class="form-control" id="password" placeholder="Password" required><!--enter password field-->	
		<hr/>
		<button type="submit" name="submit" class="btn btn-1"/>&nbsp;Register&nbsp;</button><!--register button-->
		</div>
	</form>
	<img src="https://newinti.edu.my/wp-content/uploads/2020/08/intistar.jpg"alt="Inti Logo"style="width:150px;height100px"></p><!--INTI logo-->
	<form action="index.php" method="post">
		<br><br><br><br><br><br><br><button type="submit" name="submit" class="btn btn-1"> &nbsp;Log In </button>&nbsp;<!--go to student login page-->
	</form>
	                </div>
            </div>
        </div>

    <?php include('includes/footer.php');?><!--include footer.php file to display footer-->

</body>
</html>
<!--code end-->
