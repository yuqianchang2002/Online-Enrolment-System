<?php
session_start();
include("includes/config.php");// link config.php file to connect database
$_SESSION['login']=="";
date_default_timezone_set('Asia/Kuala_Lumpur');//Kuala Lumpur time
$ldate=date( 'Y-m-d H:i:s ', time () );//exp output: 2021-9-11 18:44

mysqli_query($con,"UPDATE userlog  SET logout = '$ldate' WHERE studentRegno = '".$_SESSION['login']."' ORDER BY id DESC LIMIT 1");
session_unset();
$_SESSION['errmsg']="You have successfully logout";//inform users he/ she log out successfully
?>
<script language="javascript">
document.location="index.php";
</script>
