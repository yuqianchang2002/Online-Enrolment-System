<?php
session_start();
include('includes/config.php');// include config.php file to connect the database
error_reporting(0);
if(strlen($_SESSION['login'])==0 or strlen($_SESSION['pcode'])==0)
    {   
header('location:index.php');
}
else{

if(isset($_POST['submit']))//system will run this code when user press enroll button
{
//define variable
$studentregno=$_POST['studentregno'];
$studentname=$_POST['studentname'];
$pincode=$_POST['Pincode'];
$sem=$_POST['semester'];
$price=$_POST['price'];
$course=$_POST['course'];
$ret=mysqli_query($con,"insert into courseenrolls(studentRegno,studentName,pincode,semester,price,course) values('$studentregno','$studentname','$pincode','$sem','$price','$course')");//insert data into courseenrolls table
if($ret)
{
$_SESSION['msg']="Enroll Successfully !!";
}
else
{
  $_SESSION['msg']="Error : Not Enroll";
}
}
?>
<html>
<head>
    <meta charset="utf-8" />
    <title>Student | Course Enroll</title><!--Page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['login']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Course Enroll </h1>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Available Courses
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table"><!--table to display available course-->
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Course Code</th>
                                            <th>Course Name </th>
                                            <th>Course Price</th>
                                            <th>Course Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"select * from course");//select all data from course table
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>


                                        <tr>
                                            <td><?php echo $cnt;?></td>
                                            <td><?php echo htmlentities($row['courseCode']);?></td><!--table to display available course code-->
                                            <td><?php echo htmlentities($row['courseName']);?></td><!--table to display available course name-->
                                            <td><?php echo htmlentities($row['coursePrice']);?></td><!--table to display available course price-->
                                             <td><?php echo htmlentities($row['status']);?></td><!--table to display available course status-->
                                        </tr>
<?php 
$cnt++;//loop for counter to add itself
} ?>                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <div class="row" >
                  <div class="col-md-1"></div>
                    <div class="col-md-2">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                          Course Enroll
                        </div>
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>
<?php $sql=mysqli_query($con,"select * from students where StudentRegno='".$_SESSION['login']."'");//select the specific data from students according to the registration number from login ppage
$cnt=1;
while($row=mysqli_fetch_array($sql))
{ ?>
<div class="panel-body">
<form method="post" enctype="multipart/form-data">
   <div class="form-group">
    <label for="studentname">Student Name  </label>
    <input type="text" class="form-control" id="studentname" name="studentname" value="<?php echo htmlentities($row['studentName']);?>"  /><!--enter student name field-->
  </div>

 <div class="form-group">
    <label for="studentregno">Student Reg No   </label>
    <input type="text" class="form-control" id="studentregno" name="studentregno" value="<?php echo htmlentities($row['StudentRegno']);?>"  placeholder="Student Reg no" readonly /><!--enter student registration no field-->
    
  </div>

<div class="form-group">
    <label for="Pincode">Pincode  </label>
    <input type="text" class="form-control" id="Pincode" name="Pincode" readonly value="<?php echo htmlentities($row['pincode']);?>" required /><!--enter student pincode field-->
  </div>   
 <?php } ?>
 
<div class="form-group">
    <label for="semester">Semester  </label>
    <select class="form-control" name="semester" required="required"><!--choose semester field-->
   <option value="">Select Semester</option>   
   <?php 
$sql=mysqli_query($con,"select * from semester");
while($row=mysqli_fetch_array($sql))
{
?>
<option value="<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['semester']);?></option>
<?php } ?>

    </select> 
  </div> 

<div class="form-group">
    <label for="Course">Course  </label>
    <select class="form-control" name="course" id="course" onBlur="courseAvailability()" required="required"><!--choose course name field-->
   <option value="">Select Course</option>   
   <?php 
$sql=mysqli_query($con,"select * from course");
while($row=mysqli_fetch_array($sql))
{
?>
<option value="<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['courseName']);?></option>
<?php } ?>
    </select> 
    <span id="course-availability-status1" style="font-size:12px;">
  </div>

<div class="form-group">
    <label for="Price">Price  </label>
    <select class="form-control" name="price" id="price" onBlur="courseAvailability()" required="required"><!--choose course price field-->
   <option value="coursePrice">Course Price</option>   
   <?php 
$sql=mysqli_query($con,"select * from price");
while($row=mysqli_fetch_array($sql))
{
?>
<option value="<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['price']);?></option>
<?php } ?>
    </select> 
  </div>  

 <button type="submit" name="submit" id="submit" class="btn btn-1">Enroll</button><!--Enroll button-->
</form>
                            </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->
<script>
function courseAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'courseName='+$("#course").val(),	
type: "POST",
success:function(data){
$("#course-availability-status1").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>
</body>
</html>
<?php } ?>
<!--code end-->
