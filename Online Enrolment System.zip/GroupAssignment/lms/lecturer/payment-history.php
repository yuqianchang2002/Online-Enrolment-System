<?php
session_start();
include('includes/config.php');//include config.php file to connect to database
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{



?>

<html>
<head>
    <meta charset="utf-8"/>
    <title>Lecturer | Payment History</title><!--Page Title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--connect to css files to use the class in the css files-->
    <link href="css/style.css" rel="stylesheet" /><!--connect to css files to use the class in the css files-->
</head>

<body>
<?php include('includes/header.php');?><!--inclde  header.php files to display header in this page-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar in this page
}
 ?>
    <div class="content-wrapper"><!--content wrapper-->
        <div class="container"><!--container-->
              <div class="row"><!--row-->
                    <div class="col-md-3"><!--col-md-3-->
                        <h1 class="page-head-line">Payment History  </h1><!--Header to display "Payment History"-->
                    </div><!--col-md-3 end-->
                </div><!--row end-->
                <div class="row" ><!--row-->
                <div class="col-md-3"><!--col-md-3-->
                    <div class="panel panel-default">
                        <div class="panel-heading"><!--panel heading-->
                           Payment History
                        </div><!--panel heading end-->
                        <div class="panel-body"><!--panel body-->
                            <div class="table-responsive table-bordered"> <!--tabble border-->
                                <table class="table"><!--Table to display payment history-->
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                                 <th>Student Name </th>
                                                    <th>Student Registration no </th>
                                            <th>Price (RM)</th>
                                            <th>Date</th>
											<th>Month</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"Select * From payment");//Select all columns in payment table in myphpAdmin
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>

                                        <tr>
                                            <td><?php echo $cnt;?></td>
                                              <td><?php echo ($row['studentRegno']);?></td><!--Display student ID-->
                                            <td><?php echo htmlentities($row['studentName']);?></td><!--Display student Name-->
                                            <td><?php echo htmlentities($row['price']);?></td><!--Display student ID-->
                                            <td><?php echo htmlentities($row['date']);?></td><!--Display date of payment-->
                                            <td><?php echo htmlentities($row['month']);?></td><!--Display month of payment-->								
                                        </tr>
<?php 
$cnt++;
} ?>
                                    </tbody>
                                </table><!--table end-->
                            </div><!--tale border end-->
<?php
//search function
if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM payment WHERE (month=$valueTosearch)";
    $search_result = filterTable($query);
    
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "learningmanagementsystem");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}
//search function end
?>
							<div class="table-responsive table-bordered">
                               <table class="table"><!--Table to display search result-->
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                                 <th>Student Name </th>
                                                    <th>Student Reg no </th>
                                            <th>Price (RM)</th>
                                            <th>Date</th>
											<th>Month</th>
                                        </tr>
                                    </thead>
                                    <tbody>                       
	<form>									
   <div class="form-group">	
    <label for="month">Enter Month</label> <!--for user to input data to search-->
    <input type="text" class="form-control" id="month" name="month" placeholder="Month" required />
  </div>
  <button type="submit" name="submit" class="btn btn-1">Search</button>
   </form>

  <?php while($row = mysqli_fetch_array($search_result)):?>
                  <tr>
                   <td><?php echo $cnt;?></td>
                    <td><?php echo ($row['studentRegno']);?></td><!--Display student ID-->
                    <td><?php echo htmlentities($row['studentName']);?></td><!--Display student Name-->
                    <td><?php echo htmlentities($row['price']);?></td><!--Display student ID-->
                      <td><?php echo htmlentities($row['date']);?></td><!--Display date of payment-->
                      <td><?php echo htmlentities($row['month']);?></td><!--Display month of payment-->								
                                        </tr>
                <?php endwhile;?>
            </tbody>
			</table><!--End of tabble-->
                        </div><!--panel body end-->
                    </div><!--col-md-3 end-->
				</div><!--row end-->
            </div><!--container end-->
	        </div>><!--content wrapper end-->
  <?php include('includes/footer.php');?>
	</body>
</html>
<?php } ?>
