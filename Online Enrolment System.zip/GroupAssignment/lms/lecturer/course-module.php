<?php
session_start();
include('includes/config.php');// include config.php file to connect the database

if(ISSET($_POST['submit'])){
//retrieve file title
		$title = $_POST["title"];
//file name with a random number so that similar don't get replaced		
		$pname = rand(1000,10000)."-".$_FILES["file"]["name"];
//temporary file name		
		$tname = $_FILES["file"]["tmp_name"];
//upload file path
		$location = "files/";
//Move upload file to specific location
		move_uploaded_file($tname,$location.'/'.$pname);
//sql query to insert into database
$sql = "INSERT into fileup(title,file) VALUES('$title','$pname')";
if(mysqli_query($con,$sql)){
	echo "File Successfully uploaded";
}
else{
	echo "Error";
}

	}
?>
<html>
<head>
<title>
lecturer Upload Course Module <!--Page Title-->
</title>
</head>
<body>
<?php include('includes/header.php');?> <!--include header.php file to display header-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php'); //include menubar.php file to display menubar-->
}
?>
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
    <div class="content-wrapper"><!--content-wrapper-->
        <div class="container"><!--container-->
              <div class="row"><!--row-->
                    <div class="col-md-3"><!--col-md-3 -->
                        <h1 class="page-head-line">Upload course module </h1>
                    </div><!--col-md-3 section end-->
                </div><!--row section end-->
                <div class="row" ><!--row-->
                  <div class="col-md-1"></div><!-- to display the table in center -->
                    <div class="col-md-2"><!--col-md-2-->

<form action="course-module.php" method="post" enctype="multipart/form-data"><!--form for user to upload file-->
  <label>Enter File Title</label>
  <input type="text" name="title" id="title"><br><!--input file name-->
  <label>Select file to upload:</label>
  <input type="file" name="fileToUpload" id="fileToUpload"><!--choose file to upload-->
  <input type="submit" value="Upload" name="submit" class="btn btn-1"><!--upload file button-->
</form>
  </div><!--col-md-2 section end-->
  </div><!--row section end-->
  </div><!--container section end-->
  </div><!--content-wrapper section end-->
  <?php include('includes/footer.php');?><!--include footer.php file to display footer-->

</body>
</html>
<!--code end-->