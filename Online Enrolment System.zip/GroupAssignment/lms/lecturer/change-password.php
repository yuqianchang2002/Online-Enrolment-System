<?php
session_start();//session start
include('includes/config.php');//connect to database 
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kuala_Lumpur');//timezone in Malaysia
$currentTime = date( 'Y-m-d H:i:s', time ()  );//exp output:2021-8-31 18:50:11

if(isset($_POST['submit'])) //select password from database and update in database once users pressed the submit button
{
$sql=mysqli_query($con,"SELECT password FROM  lecturer where password='".md5($_POST['cpass'])."' && username='".$_SESSION['alogin']."'");//find password
$num=mysqli_fetch_array($sql);
if($num>0)
{
 $con=mysqli_query($con,"update lecturer set password='".md5($_POST['newpass'])."', updationDate='$currentTime' where username='".$_SESSION['alogin']."'");//update password
$_SESSION['msg']="Password Changed Successfully !!"; //inform user if system updated his/her password successfully
}
else
{
$_SESSION['msg']="Old Password not match !!";//inform user if system updated his/her password failed
}
}
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Lecturer | Change Password</title> <!--Title of the page-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--connect to bootstrap.css files to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--connect to style.css files to use the design-->
</head>
<script type="text/javascript">
function valid()
{
if(document.chngpwd.cpass.value=="")//display a message to inform user when current password field is empty
{
alert("Current Password Field is Empty !!");
document.chngpwd.cpass.focus();
return false;
}
else if(document.chngpwd.newpass.value=="")//display a message to inform user when new password field is empty
{
alert("New Password Field is Empty !!");
document.chngpwd.newpass.focus();
return false;
}
else if(document.chngpwd.cnfpass.value=="")//display a message to inform user when confirm password field is empty
{
alert("Confirm Password Field is Empty !!");
document.chngpwd.cnfpass.focus();
return false;
}
else if(document.chngpwd.newpass.value!= document.chngpwd.cnfpass.value)//display a message to inform user when new password and confirm password field not same
{
alert("Password and Confirm Password Field do not match  !!");
document.chngpwd.cnfpass.focus();
return false;
}
return true;
}
</script>
<body>
<?php include('includes/header.php');?>    <!-- include header.php file to display header in this page-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php'); //include menubar.php file to display menubar in this page
}
 ?>
    <div class="content-wrapper"><!--content wrapper-->
        <div class="container"><!--container-->
              <div class="row"><!--row-->
                    <div class="col-md-3"><!--col md--3-->
                        <h1 class="page-head-line">Lecturer Change Password </h1>
                    </div><!--col md-3 end-->
                </div><!--row end-->
                <div class="row" ><!--row-->
                  <div class="col-md-1"></div><!--to make sure the table can be displayed center-->
                    <div class="col-md-2"><!--col md 2-->
                        <div class="panel panel-default"><!--default panel-->
                        <div class="panel-heading"><!--panel heading-->
                           Change Password
                        </div><!--Panel heading end-->
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font> <!--inform user whether his/her password is changed or failed to change-->


   <div class="panel-body"><!--Panel body-->
   <form name="chngpwd" method="post" onSubmit="return valid();"><!--Change Password form-->
   <div class="form-group"><!--form-group-->
    <label for="exampleInputPassword1">Current Password</label>  
    <input type="password" class="form-control" id="exampleInputPassword1" name="cpass" placeholder="Password" /><!--Column which give user to type his current password-->
  </div><!--form-group end-->
   <div class="form-group"><!--form-group-->
    <label for="exampleInputPassword1">New Password</label>
    <input type="password" class="form-control" id="exampleInputPassword2" name="newpass" placeholder="Password" /><!--Column which give user to type his new password-->
  </div><!--form-group end-->
  <div class="form-group"><!--form-group-->
    <label for="exampleInputPassword1">Confirm Password</label>
    <input type="password" class="form-control" id="exampleInputPassword3" name="cnfpass" placeholder="Password" /><!--Column which give user to type his confirm password-->
  </div><!--form-group end-->
 
  <button type="submit" name="submit" class="btn btn-1">Submit</button> <!--submit button-->
                           <hr />
</form><!--Change Password form end-->
</div><!--Panel body end-->
</div><!--default panel end-->
</div><!--col md 2 end-->              
</div><!--row end-->
</div><!--container end-->
</div><!--content wrapper end-->
  <?php include('includes/footer.php');?> <!-- include footer.php file to display footer in this page -->
</body>
</html>
<?php } ?>
<!--End of the code-->
