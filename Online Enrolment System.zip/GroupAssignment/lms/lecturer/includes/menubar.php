<section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                             
							 <li><a href="course.php">Course</a></li>
                               <li><a href="course-module.php">Course Module</a></li>                              
							  <li><a href="payment-history.php">Payment History</a></li>
                               <li><a href="enroll-history.php">Enroll History</a></li>
                               <li><a href="user-log.php">Student Logs </a></li>
                            <li><a href="logout.php">Logout</a></li>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>