<?php
session_start();
include('includes/config.php');//include config.php file to connect to database
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Lecturer | Enroll History</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--connect to bootstrap.css files to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--connect to style.css files to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!-- include header.php file to display header in this page-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar in this page 
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Enroll History  </h1> 
                    </div>
                </div>
                <div class="row" >            
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Enroll History
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table"><!--Table to display enroll history-->
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Student Name </th>
                                            <th>Student Reg No </th>
                                            <th>Course Name </th>
                                            <th>Semester</th>
                                             <th>Enrollment Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"select courseenrolls.course as cid, course.courseName as courname,semester.semester as sem,courseenrolls.enrollDate as edate ,students.studentName as sname,students.StudentRegno as sregno from courseenrolls join course on course.id=courseenrolls.course join semester on semester.id=courseenrolls.semester   join students on students.StudentRegno=courseenrolls.studentRegno ");
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>


                                        <tr>
                                            <td><?php echo $cnt;?></td>
                                              <td><?php echo htmlentities($row['sname']);?></td>
                                            <td><?php echo htmlentities($row['sregno']);?></td>
                                            <td><?php echo htmlentities($row['courname']);?></td>
                                            <td><?php echo htmlentities($row['sem']);?></td>
											<td><?php echo htmlentities($row['edate']);?></td>
                                            <td>
                                            <a href="print.php?id=<?php echo $row['cid']?>" target="_blank">
                                            </td>
                                        </tr>
<?php 
$cnt++;
} ?>

                                    </tbody>
                                </table><!--End of table-->
                            </div>
                        </div>
                    </div>
<?php
//search function
if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM curseenrolls WHERE (course=$valueTosearch)";
    $search_result = filterTable($query);
    
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "learningmanagementsystem");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}
//search function end
?>
							<div class="table-responsive table-bordered">
                               <table class="table"><!--Table to display search result-->
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                                 <th>Student Name </th>
                                                    <th>Student Reg No </th>
                                            <th>Course Name </th>
                                            <th>Semester</th>
                                             <th>Enrollment Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>                       
	<form>									
   <div class="form-group">	
    <label for="course">Enter Course Name</label> <!--for user to input data to search-->
    <input type="text" class="form-control" id="course" name="course" placeholder="Course Name" required />
  </div>
  <button type="submit" name="submit" class="btn btn-1">Search</button>
   </form>

  <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['studentName'];?></td>
                    <td><?php echo $row['studentRegno'];?></td>
                    <td><?php echo $row['courseName'];?></td>
                    <td><?php echo ($row['semester']);?></td>					
                    <td><?php echo $row['enrollDate'];?></td>
                </tr>
                <?php endwhile;?>
            </tbody>
			</table><!--End of tabble-->
</div>
</div>
</div>
</div>
</div>
  <?php include('includes/footer.php');?>    <!-- include footer.php file to display footer in this page -->
</body>
</html>
<?php } ?>
<!--End of the code-->