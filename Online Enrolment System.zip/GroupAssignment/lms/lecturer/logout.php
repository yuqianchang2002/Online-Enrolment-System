<?php
session_start();
$_SESSION['alogin']=="";
session_unset();
$_SESSION['errmsg']="You have successfully logout";//inform users his/her account is logged out
?>
<script language="javascript">
document.location="index.php";
</script>
