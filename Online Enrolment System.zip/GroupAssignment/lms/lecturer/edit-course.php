<?php
session_start();
include('includes/config.php');//include config.php file to link the database
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
$id=intval($_GET['id']);
date_default_timezone_set('Asia/Kuala_Lumpur');//KL time
$currentTime = date( 'Y-m-d H:i:s ', time ()  );//exp output:2021:12:13 14:55
if(isset($_POST['submit']))//system will run this code when user press the update button
{
//define variable
$coursecode=$_POST['coursecode'];
$coursename=$_POST['coursename'];
$coursePrice=$_POST['coursePrice'];
$status=$_POST['status'];
$ret=mysqli_query($con,"update course set courseCode='$coursecode',courseName='$coursename',coursePrice='$coursePrice',status='$status',updationDate='$currentTime' where id='$id'");//update courses by selecting specific data from course table
if($ret)
{
$_SESSION['msg']="Course Updated Successfully !!";//inform user he/she updated the course successfully
}
else
{
  $_SESSION['msg']="Error : Course not Updated";//inform user he/she fail to update the course
}
}
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Lecturer | Course</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--Link to bootsrap.css file to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--Link to style.css file to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Edit Course  </h1>
                    </div>
                </div>
                <div class="row" >
                  <div class="col-md-1"></div>
                    <div class="col-md-2">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           Edit Course 
                        </div>
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>


                        <div class="panel-body">
                       <form method="post">
<?php
$sql=mysqli_query($con,"select * from course where id='$id'");
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>
<p><b>Last Updated at</b> :<?php echo htmlentities($row['updationDate']);?></p>
   <div class="form-group">
    <label for="coursecode">Course Code  </label>
    <input type="text" class="form-control" id="coursecode" name="coursecode" placeholder="Course Code" value="<?php echo htmlentities($row['courseCode']);?>" required />
  </div>

 <div class="form-group">
    <label for="coursename">Course Name  </label>
    <input type="text" class="form-control" id="coursename" name="coursename" placeholder="Course Name" value="<?php echo htmlentities($row['courseName']);?>" required />
  </div>

<div class="form-group">
    <label for="coursePrice">Price  </label>
    <select class="form-control" name="coursePrice" id="coursePrice" onBlur="courseAvailability()" required="required">
   <option value="coursePrice">Course Price</option>   
   <?php 
$sql=mysqli_query($con,"select * from price");
while($row=mysqli_fetch_array($sql))
{
?>
<option value="<?php echo htmlentities($row['price']);?>"><?php echo htmlentities($row['price']);?></option>
<?php } ?>
    </select> 
  </div>
  
<div class="form-group">
    <label for="status">Course Status  </label>
    <input type="text" class="form-control" id="status" name="status" placeholder="Course Status" value="<?php echo htmlentities($row['status']);?>" required />
  </div>  
<?php } ?>
 <button type="submit" name="submit" class="btn btn-1"> Update</button>
</form>
                            </div>
                            </div>
                    </div>
                  
                </div>
            </div>
        </div>
    </div>
  <?php include('includes/footer.php');?><!--include header.php file to display header-->
</body>
</html>
<?php } ?>
<!--code end-->
