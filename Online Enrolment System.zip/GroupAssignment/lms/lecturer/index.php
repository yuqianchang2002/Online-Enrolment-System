<?php
session_start();
error_reporting(0);
include("includes/config.php");//include config.php file to connect to database 
if(isset($_POST['submit']))
{
    $username=$_POST['username'];
    $password=md5($_POST['password']);
$query=mysqli_query($con,"SELECT * FROM lecturer WHERE username='$username' and password='$password'");
$num=mysqli_fetch_array($query);
if($num>0)
{
$extra="change-password.php";
$_SESSION['alogin']=$_POST['username'];
$_SESSION['id']=$num['id'];
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
else
{
$_SESSION['errmsg']="Invalid username or password";
$extra="index.php";
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
}
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Lecturer | Login</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--connect to bootstrap.css files to use the design-->
    <link href="css/style.css" rel="stylesheet" /><!--connect to style.css files to use the design-->
</head>
<body>
    <?php include('includes/header.php');?><!-- include header.php file to display header in this page-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h4 class="page-head-line">Lecturer Login Page </h4>

                </div>

            </div>
             <span style="color:red;" ><?php echo htmlentities($_SESSION['errmsg']); ?><?php echo htmlentities($_SESSION['errmsg']="");?></span>
            <form method="post">
            <div class="row">
                <div class="col-md-2">
                     <label>Enter Username : </label>
                        <input type="text" name="username" class="form-control" required />
                        <label>Enter Password :  </label>
                        <input type="password" name="password" class="form-control" required />
                        <hr />
                        <button type="submit" name="submit" class="btn btn-1"> &nbsp;Log In </button>&nbsp;<!--login  button-->
                </div>
                </form>
				<img src="https://newinti.edu.my/wp-content/uploads/2020/08/intistar.jpg"alt="Inti Logo"style="width:150px;height100px"></p><!--INTI logo-->

                               </div>
				<form method="POST" action="http://localhost/GroupAssignment/lms/headofprogram/index.php">
      				<button type="submit" name="submit" class="btn btn-1"/> &nbsp;HOP Login</button>&nbsp;<!--HOP login button to lead user to the HOP login page-->
				</form>	

            </div>
        </div>
    </div>
    <?php include('includes/footer.php');?><!-- include footer.php file to display footer in this page-->
</body>
</html>
<!--code end-->