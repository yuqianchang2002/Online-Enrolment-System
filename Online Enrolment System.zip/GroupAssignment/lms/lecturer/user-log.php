<?php
session_start();
include('includes/config.php');//connect to database 
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{



?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Lecturer | User Login</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--connect to css files to use the class in the css files-->
    <link href="css/style.css" rel="stylesheet" /><!--connect to css files to use the class in the css files-->
</head>

<body>
<?php include('includes/header.php');?><!--include  header.php files to display header in this page-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include  menubar.php files to display menubar in this page
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">User Login History  </h1>
                    </div>
                </div>
                <div class="row" >
            
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           User Login History
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                                
                                                    <th>Student Reg no </th>
                                            <th>Login Time </th>
                                            
                                                <th>Logout Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"select * from userlog");
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>
                                        <tr>
                                            <td><?php echo $cnt;?></td>
                                              <td><?php echo htmlentities($row['studentRegno']);?></td>
                                            <td><?php echo htmlentities($row['loginTime']);?></td>
                                            <td><?php echo htmlentities($row['logout']);?></td>
                                        </tr>
<?php 
$cnt++;
} ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
  <?php include('includes/footer.php');?><!--include footer.php files to display footer in this page-->
</body>
</html>
<?php } ?>
<!--code end-->