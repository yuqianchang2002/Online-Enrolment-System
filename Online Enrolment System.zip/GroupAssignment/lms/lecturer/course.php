<?php
session_start();
include('includes/config.php');//connect to database
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{

if(isset($_POST['submit']))//system will run this code when user press the submit button
{
//define variable
$coursecode=$_POST['coursecode'];
$coursename=$_POST['coursename'];
$coursePrice=$_POST['coursePrice'];
$status=$_POST['status'];
$ret=mysqli_query($con,"insert into course(courseCode,courseName,coursePrice,status) values('$coursecode','$coursename','$coursePrice','$status')");//insert data into course table
if($ret)
{
$_SESSION['msg']="Course Created Successfully !!";//inform user course is created successfully
}
else
{
  $_SESSION['msg']="Error : Course not created";//inform user course is fail to create
}
}
?>

<html>
<head>
    <meta charset="utf-8" />
    <title>Lecturer | Course</title><!--page title-->
    <link href="css/bootstrap.css" rel="stylesheet" /><!--connect to bootstrap.css files to use the design -->
    <link href="css/style.css" rel="stylesheet" /><!--connect to style.css files to use the design-->
</head>

<body>
<?php include('includes/header.php');?><!--include header.php file to display header in this page-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');//include menubar.php file to display menubar in this page
}
 ?>
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-3">
                        <h1 class="page-head-line">Add/Edit Course  </h1>
                    </div>
                </div>
                <div class="row" >
                  <div class="col-md-1"></div>
                    <div class="col-md-2">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           Add Course 
                        </div>
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>


<div class="panel-body">
<form method="post"><!--add course form-->
   <div class="form-group">
    <label for="coursecode">Course Code  </label>
    <input type="text" class="form-control" id="coursecode" name="coursecode" placeholder="Course Code" required /><!--enter course code field-->
  </div>

 <div class="form-group">
    <label for="coursename">Course Name  </label>
    <input type="text" class="form-control" id="coursename" name="coursename" placeholder="Course Name" required /><!--enter course name field-->
  </div>

<div class="form-group">
    <label for="coursePrice">Price  </label>
    <select class="form-control" name="coursePrice" id="coursePrice" onBlur="courseAvailability()" required="required"><!--select course price field-->
   <option value="coursePrice">Course Price</option>   
   <?php 
$sql=mysqli_query($con,"select * from price");// select all data from price table
while($row=mysqli_fetch_array($sql))
{
?>
<option value="<?php echo htmlentities($row['price']);?>"><?php echo htmlentities($row['price']);?></option>
<?php } ?>
    </select> 
  </div>
    
<div class="form-group">
    <label for="status">Status  </label>
    <input type="text" class="form-control" id="status" name="status" placeholder="Course Status" required /><!--enter course status field-->
  </div>   

 <button type="submit" name="submit" class="btn btn-1">Submit</button>
</form>
                            </div>
                            </div>
                    </div>
                  
                </div>
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Edit Course
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table"><!--display added courses-->
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Course Code</th>
                                            <th>Course Name </th>
											<th>Course Price</th>
                                            <th>Course Status</th>
                                             <th>Creation Date</th>
                                             <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"select * from course");//select all data in course table
$cnt=1;//counter start from 1
while($row=mysqli_fetch_array($sql))
{
?>
                                        <tr>
                                            <td><?php echo $cnt;?></td><!--display amount of data-->
                                            <td><?php echo htmlentities($row['courseCode']);?></td><!--display course code-->
                                            <td><?php echo htmlentities($row['courseName']);?></td><!--display course name-->
                                            <td><?php echo htmlentities($row['coursePrice']);?></td><!--display course price-->
                                             <td><?php echo htmlentities($row['status']);?></td><!--display course status-->
                                            <td><?php echo htmlentities($row['creationDate']);?></td><!--display course creation date-->
                                            <td>
                                            <a href="edit-course.php?id=<?php echo $row['id']?>">
<button class="btn btn-1">Edit</button> </a><!--edit button-->                                       
                                            </td>
                                        </tr>
<?php 
$cnt++;//loop for counter to count and display number of courses
} ?>                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <?php include('includes/footer.php');?><!--include header.php file to display header in this page-->
</body>
</html>
<?php } ?>
<!--code end-->
